package util;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestData {

	static File file;
	static FileInputStream fis;
	static XSSFWorkbook book;
	static XSSFSheet sheet;

	public static int getNoofRows() {
		int RowCount = sheet.getLastRowNum();
		return RowCount;
	}
	
	
	public static String getData(String sheetname, int rownumber,int cellnumber) {

		file = new File();
		fis =  new FileInputStream(file);
		book = new XSSFWorkbook(fis);
		sheet = book.getSheet(sheetname);
		String value = null;


		int RowCount = TestData.getNoofRows();
		
		int CellCount = sheet.getRow(0).getLastCellNum();

		for(int i=0;i<RowCount;i++) {

			for(int j=0;j<CellCount;i++) {	
				value = sheet.getRow(i).getCell(j).getStringCellValue();
			}
		}

		return value;

	}


}
